package com.cts.retailproductvendor.feign;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;




@ExtendWith(MockitoExtension.class)
public class TestAuthClientFallback {
	@InjectMocks

	AuthClientFallback authClientFallback;
	
	@Test
	void getValidity()   {
		boolean result = authClientFallback.getValidity("test");
		assertFalse(result);
	}
	@Test
	void getId() {
		long result = authClientFallback.getId("token");
		assertEquals(0, result);

	}



}

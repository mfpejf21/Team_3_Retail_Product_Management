package com.cts.retailproductvendor.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
@ExtendWith(MockitoExtension.class)
public class TestVendor {

	Vendor vendor = new Vendor();

	@Test
	@DisplayName("Checking if vendor class is loading or not.")
	void viewBillsDTODTOIsLoadedOrNot() {
		Vendor vendor = new Vendor();
		assertThat(vendor).isNotNull();
	}
	
      @Test
      void vendorId() {
    	  Vendor vendor = new Vendor();
    	  vendor.setVendorId(1);
    	  assertEquals(1, vendor.getVendorId());
      }
      
      @Test
      void vendorName() {
    	  Vendor vendor = new Vendor();
    	  vendor.setVendorName("kiran");
    	  assertEquals("kiran", vendor.getVendorName());
      }
      @Test
      void deliveryCharge() {
    	  Vendor vendor = new Vendor();
    	  vendor.setDeliveryCharge(59);
    	  assertEquals(59, vendor.getDeliveryCharge());
      }
      
     
	@Test
      void rating() {
    	  Vendor vendor = new Vendor();
    	  vendor.setRating(8);
    	  assertEquals(8, vendor.getRating());
      }
      
      @Test
      public void AllArgConstTest() {
    	  Vendor vendor = new Vendor(1,"kiran",50,9);
  		assertEquals(1, vendor.getVendorId());
  		assertEquals("kiran", vendor.getVendorName());
  		assertEquals(50, vendor.getDeliveryCharge());
  		assertEquals(9, vendor.getRating());
}
     @Test
  	public void noArgsConstructorTest() {
  		
    	 Vendor vendor1 = new Vendor();
  		assertEquals(vendor1, vendor1);
  	}
}

	



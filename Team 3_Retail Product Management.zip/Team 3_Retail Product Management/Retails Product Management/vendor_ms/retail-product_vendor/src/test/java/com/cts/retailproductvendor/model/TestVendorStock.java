package com.cts.retailproductvendor.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
@ExtendWith(MockitoExtension.class)
public class TestVendorStock {

	
VendorStock vendorStock=new VendorStock();

	
	@Test
	@DisplayName("Checking if VendorStock class is loading or not.")
	void viewBillsDTODTOIsLoadedOrNot() {
		VendorStock vendorStock=new VendorStock();
		assertThat(vendorStock).isNotNull();
	}
	@Test
	void vendorStockId() {
		vendorStock.setVendorStockId(2);;
		assertEquals(2, vendorStock.getVendorStockId());
	}
	
	@Test
	void productId() {
		vendorStock.setProductId(4);;
		assertEquals(4, vendorStock.getProductId());
	}
	
	@Test
	void vendorId() {
		vendorStock.setVendorId(1);
		assertEquals(1,vendorStock.getVendorId());
	}
	
	@Test
	void stockInHand() {
		vendorStock.setStockInHand(45);
		assertEquals(45, vendorStock.getStockInHand());
	}
	
	@Test
	void expectedStockReplinshmentDate() {
		LocalDate date = LocalDate.of(2017, 1, 13);
		vendorStock.setExpectedStockReplinshmentDate(date);
		assertEquals(date, vendorStock.getExpectedStockReplinshmentDate());
	}
	
	@Test
	public void AllArgConstTest() {
		LocalDate date = LocalDate.of(2017, 1, 13);
		VendorStock vendorStock=new VendorStock(1,1,1,40,date);
		assertEquals(1, vendorStock.getVendorStockId());
		assertEquals(1, vendorStock.getProductId());
		assertEquals(1, vendorStock.getVendorId());
		assertEquals(40, vendorStock.getStockInHand());
		assertEquals(date, vendorStock.getExpectedStockReplinshmentDate());

	}
	
}





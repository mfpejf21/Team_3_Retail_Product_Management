package com.cts.retailproductvendor.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class VendorStock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int vendorStockId;
    public int productId;
    public int vendorId;
    public int stockInHand;
    public LocalDate expectedStockReplinshmentDate;
}

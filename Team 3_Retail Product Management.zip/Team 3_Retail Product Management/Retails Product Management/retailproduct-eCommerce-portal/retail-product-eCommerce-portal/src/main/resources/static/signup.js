/**
 * 
 */
var check = function() {
	  if (document.getElementById('upassword').value ==
		    document.getElementById('confirmPassword').value) {
		    document.getElementById('message').style.color = 'green';
		    document.getElementById('message').innerHTML = 'matching';
		  } else {
		    document.getElementById('message').style.color = 'red';
		    document.getElementById('message').innerHTML = 'not matching';
		  }
		}

 function validateSignupForm() {
	var mail = document.getElementById("email").value;
	var fname = document.getElementById("firstName").value;
	var lname = document.getElementById("lastName").value;
	var pswd = document.getElementById("upassword").value;
	var uname = document.getElementById("uname").value;
	var zcode= document.getElementById("zipCode").value;
	var address = document.getElementById("address").value;
	
	if ( fname == "") {
		alert("Please Enter First Name in Field ");
		//document.getElementById("errorMsg").innerHTML = "Please fill the required fields"
		return false;
	}
	else if ( lname == "") {
		alert("Please Enter Last Name in Field ");
		//document.getElementById("errorMsg").innerHTML = "Please fill the required fields"
		return false;
	}
	else if (  uname == "") {
		alert("Please Enter User Name in Field ");
		//document.getElementById("errorMsg").innerHTML = "Please fill the required fields"
		return false;
	}
	
	else if (  address == "") {
		alert("Please Enter Address in Field ");
		//document.getElementById("errorMsg").innerHTML = "Please fill the required fields"
		return false;
	}
	
	else if(zcode == ""){
		alert("Please Enter Zip Code in Field ");
		return false;
	}
	else if(pswd ==""){
		alert("Please Enter Password Code in Field ");
		return false;
	}
	
	else {
		alert("Successfully signed up");
		return true;
	}
}
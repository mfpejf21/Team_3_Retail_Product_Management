package com.cts.retailproducteCommerceportal.exception;

public class InternalServerErrorException extends Exception {

    public InternalServerErrorException(String msg) {
        // TODO Auto-generated constructor stub
        super(msg);
    }
}

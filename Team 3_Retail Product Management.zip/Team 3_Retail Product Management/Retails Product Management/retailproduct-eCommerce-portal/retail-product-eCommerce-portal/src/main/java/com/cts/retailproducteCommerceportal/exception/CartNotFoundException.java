package com.cts.retailproducteCommerceportal.exception;

public class CartNotFoundException extends Exception {

    public CartNotFoundException(String msg) {
        // TODO Auto-generated constructor stub
        super(msg);
    }
}

package com.cts.retailproducteCommerceportal.client;

import com.cts.retailproducteCommerceportal.exception.UnauthorisedAccessException;
import com.cts.retailproducteCommerceportal.model.Vendor;

import java.util.List;

public class VendorClientFallback implements VendorClient {

    @Override
    public List<Vendor> getVendors(String token, int productId, int quantity) throws UnauthorisedAccessException {
        // TODO Auto-generated method stub
        return null;
    }


}

package com.cts.retailproducteCommerceportal.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestUserAuth {
	
	UserAuth userAuth= new UserAuth();
	
	
	
    @Test
	void testuserid() {
    	userAuth.setUserid(1);
    	assertEquals(1, userAuth.getUserid());
    }
    @Test
	void testlastName() {
    	userAuth.setLastName("Moraye");
    	assertEquals("Moraye", userAuth.getLastName());
    }
    @Test
	void testfirstName() {
    	userAuth.setFirstName("kiran");
    	assertEquals("kiran", userAuth.getFirstName());
    }
    @Test
	void testuname() {
    	userAuth.setUname("hi");
    	assertEquals("hi", userAuth.getUname());
    }
   
    @Test
   	void testupassword() {
       	userAuth.setUpassword("bye");
       	assertEquals("bye", userAuth.getUpassword());
       }
    @Test
   	void testemail() {
       	userAuth.setEmail("hi@gmail.com");
       	assertEquals("hi@gmail.com", userAuth.getEmail());
       }
    @Test
   	void testaddress() {
       	userAuth.setAddress("mumbai");
       	assertEquals("mumbai", userAuth.getAddress());
       }
    @Test
   	void testzipCode() {
       	userAuth.setZipCode(1234);
       	assertEquals(1234, userAuth.getZipCode());
       }
    @Test
    public void AllArgConstTest() {
    	UserAuth userAuth= new UserAuth(1,"kiran","moraye","hi","bye","hi@gmail.com","mumbai",1234);
    	assertEquals(1, userAuth.getUserid());
    	assertEquals("kiran", userAuth.getFirstName());
    	assertEquals("moraye", userAuth.getLastName());
    	assertEquals("hi", userAuth.getUname());
    	assertEquals("bye", userAuth.getUpassword());
    	assertEquals("hi@gmail.com", userAuth.getEmail());
    	assertEquals("mumbai", userAuth.getAddress());
    	assertEquals(1234, userAuth.getZipCode());
    
}
   @Test
	public void noArgsConstructorTest() {
	   UserAuth userAuth1= new UserAuth();
		assertEquals(userAuth1, userAuth1);
	}

}

package com.cts.retailproducteCommerceportal.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestPasswordNotMatchException {

	@InjectMocks
	PasswordNotMatchException passwordNotMatchException;
	
	@Test
	void InternalServerErrorException() {
		passwordNotMatchException=new PasswordNotMatchException("try again");
		assertEquals("try again", passwordNotMatchException.getMessage());
	}
}

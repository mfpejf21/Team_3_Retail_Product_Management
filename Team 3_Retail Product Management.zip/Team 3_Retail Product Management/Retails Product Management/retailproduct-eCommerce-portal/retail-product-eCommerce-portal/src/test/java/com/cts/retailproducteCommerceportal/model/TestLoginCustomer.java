package com.cts.retailproducteCommerceportal.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestLoginCustomer {

	LoginCustomer loginCustomer= new LoginCustomer();
	@Test
	void testUsername() {
		loginCustomer.setUname("admin");
		assertEquals( "admin", loginCustomer.getUname());
	}

	@Test
	void testPassword() {
		loginCustomer.setPassword("admin");
		assertEquals( "admin", loginCustomer.getPassword());
	}

	@Test
    public void AllArgConstTest() {
		LoginCustomer loginCustomer= new LoginCustomer("admin","admin");
    	assertEquals("admin", loginCustomer.getUname());
    	assertEquals("admin", loginCustomer.getPassword());
    	
    
}
   @Test
	public void noArgsConstructorTest() {
	   LoginCustomer loginCustomer1= new LoginCustomer();
		assertEquals(loginCustomer1, loginCustomer1);
	}
}




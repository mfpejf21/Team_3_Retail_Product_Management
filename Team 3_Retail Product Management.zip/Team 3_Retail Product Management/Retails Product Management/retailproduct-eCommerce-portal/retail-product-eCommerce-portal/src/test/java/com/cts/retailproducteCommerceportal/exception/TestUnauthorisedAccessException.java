package com.cts.retailproducteCommerceportal.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestUnauthorisedAccessException {

	@InjectMocks
	UnauthorisedAccessException unauthorisedAccessException;
	
	@Test
	void InternalServerErrorException() {
		unauthorisedAccessException=new UnauthorisedAccessException("try again");
		assertEquals("try again", unauthorisedAccessException.getMessage());
	}
}

package com.cts.retailproducteCommerceportal.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestWishlistNotFoundException {

	@InjectMocks
	WishlistNotFoundException wishlistNotFoundException;
	
	@Test
	void InternalServerErrorException() {
		wishlistNotFoundException=new WishlistNotFoundException("try again");
		assertEquals("try again", wishlistNotFoundException.getMessage());
	}
}

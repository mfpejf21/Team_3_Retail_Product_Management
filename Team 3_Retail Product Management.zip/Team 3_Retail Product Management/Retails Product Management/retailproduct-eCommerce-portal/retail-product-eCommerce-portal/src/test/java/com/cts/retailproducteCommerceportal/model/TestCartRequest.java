package com.cts.retailproducteCommerceportal.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class TestCartRequest {
	@InjectMocks
	CartRequest cartRequest;

	@Test
	@DisplayName("Checking if cartRequest class is loading or not.")
	void viewBillsDTODTOIsLoadedOrNot() {
		CartRequest cartRequest= new CartRequest();
		assertThat(cartRequest).isNotNull();
	}
	
	@Test
	void customerId() {
		cartRequest.setCustomerId(1);
		assertEquals(1, cartRequest.getCustomerId());
	}

	@Test
	void product() {
	
		Product product=new Product(1,"kiran",50,"Product is good","product",9,10);
    	assertEquals(1, product.getId());
    	assertEquals("kiran", product.getName());
    	assertEquals("Product is good", product.getDescription());
    	assertEquals("product", product.getImage_name());;
    	assertEquals(9, product.getRating());
    	assertEquals(10, product.getCount());
	}
	
		
		 
		

	@Test
	void qty() {
		cartRequest.setQty(5);
		assertEquals(5, cartRequest.getQty());

	}

	@Test
	void zipCode() {
		cartRequest.setZipCode(400068);
		assertEquals(400068, cartRequest.getZipCode());
	}

	
	  @Test void expectedDeliveryDate() {
		  Date date= new Date();
		 
	  cartRequest.setExpectedDeliveryDate(date);
	  assertEquals(date, cartRequest.getExpectedDeliveryDate());
	  
	  }
	  
		/*
		 * @Test public void AllArgConstTest() { CartRequest cartRequest= new
		 * CartRequest() assertEquals(1, vendor.getVendorId()); assertEquals("kiran",
		 * vendor.getVendorName()); assertEquals(50, vendor.getDeliveryCharge());
		 * assertEquals(9, vendor.getRating()); }
		 */
	  
     @Test
  	public void noArgsConstructorTest() {
  		
    	 CartRequest cartRequest1= new CartRequest();
  		assertEquals(cartRequest1, cartRequest1);
  	}
	 

}

package com.cts.retailproducteCommerceportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailProductECommercePortalApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.cts.retailproductauthms.model;

import lombok.*;

import javax.persistence.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long userid;

    @Column
    private String fname;

    @Column
    private String lname;

    @Column
    private String uname;

    @Column
    private String upassword;

    @Column
    private String email;

    @Column
    private String address;

    @Column
    private int zcode;
}

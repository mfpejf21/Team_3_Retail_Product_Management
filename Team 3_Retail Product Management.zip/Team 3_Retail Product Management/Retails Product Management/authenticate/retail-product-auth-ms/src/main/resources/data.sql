INSERT INTO CUSTOMER(userid,fname,lname,uname,upassword,email,address,zcode) VALUES
(1,'shivendu','kumar','shiv','shiv','a@b.c','bihar',846004);
package com.cts.retailproductauthms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailProductAuthMsApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.cts.retailproductauthms.exception;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
@ExtendWith(MockitoExtension.class)
public class TestUserException {

	@InjectMocks
	PasswordNotMatchException passwordNotMatchException;
	
	@Test
	void InternalServerErrorException() {
		passwordNotMatchException=new PasswordNotMatchException("try again");
		assertEquals("try again", passwordNotMatchException.getMessage());
	}
}

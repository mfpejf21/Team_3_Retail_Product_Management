/*package com.cts.retailproductauthms.service;
import com.cts.retailproductauthms.dao.UserDao;
import com.cts.retailproductauthms.exception.UserAlreadyExistsException;
import com.cts.retailproductauthms.exception.PasswordNotMatchException;
import com.cts.retailproductauthms.exception.GlobalExceptionHandler;
import com.cts.retailproductauthms.model.Customer;
import com.cts.retailproductauthms.model.LoginCustomer;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TestService {

    static Customer p;
    @InjectMocks
    CustomerDetails customerDetails;
    @Mock
    UserDao dao;

    @BeforeAll
    static void initilizeCustomer() {
        p = new Customer(1,"Naveen","Claws","naveen","123","a@b.com","Vizag",992012);
    }

    @Test
    void testSearchCustomerById() {
        when(dao.findByUname("naveen")).thenReturn(Optional.ofNullable(p));
        assertEquals(customerDetails.searchCustomerById((1).get().getUserid(), p.getUserid());

    }

    @Test
    void testGetCustomerByEmail() {
        List<Customer> p = Stream.of(new Customer(1,"Naveen","Claws","naveen","123","a@b.com","Vizag",992012),
                new Customer(1,"Naveen","Claws","naveen","123","a@b.com","Vizag",992012)).collect(
                Collectors.toList());
        when(dao.findByEmail("a@b.com")).thenReturn(p);
        assertEquals(customerDetails.searchCustomerByEmail(992012).size(), 2);
        verify(dao).findByEmail("a@b.com");
    }

}
*/

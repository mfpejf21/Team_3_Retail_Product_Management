package com.cts.retailproductauthms.model;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
@ExtendWith(MockitoExtension.class)
public class TestCustomer {

	 Customer customer = new Customer();

	@Test
	
	@DisplayName("Checking if Customer class is loading or not.")
	void viewBillsDTODTOIsLoadedOrNot() {
		Customer Customer = new Customer();
		assertThat(Customer).isNotNull();
	}
	
      @Test
      void userid() {
    	  Customer Customer = new Customer();
    	  Customer.setUserid(1);
    	  assertEquals(1, Customer.getUserid());
      }
      
      @Test
      void fname() {
    	  Customer Customer = new Customer();
    	  Customer.setFname("Naveen");
    	  assertEquals("Naveen", Customer.getFname());
      }
      @Test
      void lname() {
    	  Customer Customer = new Customer();
    	  Customer.setLname("Claws");
    	  assertEquals("Claws", Customer.getLname());
      }
      
     
	@Test
      void uname() {
    	  Customer Customer = new Customer();
    	  Customer.setUname("naveen");
    	  assertEquals("naveen", Customer.getUname());
      }
	@Test
	void upassword() {
		 Customer Customer = new Customer();
   	  Customer.setUpassword("naveen");
   	  assertEquals("naveen", Customer.getUpassword());
	}
	@Test
	void email() {
		 Customer Customer = new Customer();
   	  Customer.setEmail("a@b.com");
   	  assertEquals("a@b.com", Customer.getEmail());
     
	}
	@Test
	void address() {
		 Customer Customer = new Customer();
	   	  Customer.setAddress("Vizag");
	   	  assertEquals("Vizag", Customer.getAddress());
		}
@Test
void zcode()
{
	 Customer Customer = new Customer();
  	  Customer.setZcode(992012);
  	  assertEquals(992012, Customer.getZcode());
}
      
      @Test
      public void AllArgConstTest() {
    	  Customer Customer = new Customer(1,"Naveen","Claws","naveen","123","a@b.com","Vizag",992012);
  		assertEquals(1, Customer.getUserid());
  		assertEquals("Naveen", Customer.getFname());
  		assertEquals("Claws", Customer.getLname());
  		assertEquals("naveen", Customer.getUname());
  		assertEquals("123", Customer.getUpassword());
  		assertEquals("a@b.com", Customer.getEmail());
  		assertEquals("Vizag", Customer.getAddress());
  		assertEquals(992012, Customer.getZcode());
}
     @Test
  	public void noArgsConstructorTest() {
  		
    	 Customer Customer1 = new Customer();
  		assertEquals(Customer1, Customer1);
  	}
}

	




package com.cts.retailproductms.exception;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.cts.retailproductms.feign.AuthFeign;
import com.cts.retailproductms.model.Product;
import com.cts.retailproductms.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;


@ExtendWith(MockitoExtension.class)
public class TestUnauthorisedException {
	
	static Product p;
    @MockBean
    ProductService productService;

    @MockBean
    AuthFeign authClient;

    ObjectMapper mapper = new ObjectMapper();
    @Autowired
    private MockMvc mock;

    @InjectMocks
    UnauthorisedAccessException accessUnauthorizedException;
    @Test
    void testUnauthorisedAccessException() {
        accessUnauthorizedException = new UnauthorisedAccessException("try again");
        assertEquals("try again", accessUnauthorizedException.getMessage());
    }
   
   
}
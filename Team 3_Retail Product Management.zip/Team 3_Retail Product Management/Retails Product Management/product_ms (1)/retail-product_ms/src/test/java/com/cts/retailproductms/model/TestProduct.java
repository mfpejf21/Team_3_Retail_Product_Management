package com.cts.retailproductms.model;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;

import com.cts.retailproductms.dao.ProductDao;
import com.cts.retailproductms.service.ProductService;



@SpringBootTest
@ActiveProfiles("test")
public class TestProduct {
  
	@Autowired
	private ProductDao productDao;
   
   @Autowired
   private ProductService productService;

   @Test
   public void whenUserIdIsProvided_thenRetrievedNameIsCorrect() {
      List<Product> product = null;
	
   }
   
   @Test
   public void testNoArgConstructor(){
       Product log = new Product();
     
   }
  
   
   
  
   
   public Product crateTestSuite(){
	      return new Product();
	     }
   
   
   @Test
   public void testEntity() {
    long id= 0;
    Product xyz =null;
    xyz = crateTestSuite();
    id = xyz.getId();

   }
   @Test
   public void testGetName() {
    String name= null;
    Product xyz =null;
    xyz = crateTestSuite();
    name = xyz.getName();

   }

   
   @Test
   public void testPrice() {
    double id= 0;
    Product xyz =null;
    xyz = crateTestSuite();
    id = xyz.getPrice();

   }
   @Test
   public void testCount() {
    int name= 0;
    Product xyz =null;
    xyz = crateTestSuite();
    name = xyz.getCount();

   }
   
   
   @Test
   public void testDescription() {
    String description= "Null";
    Product xyz =null;
    xyz = crateTestSuite();
    description = xyz.getDescription();

   }
   @Test
   public void testRating() {
   float rat= 0;
    Product xyz =null;
    xyz = crateTestSuite();
    rat = xyz.getRating();

   }
   
  


   
}


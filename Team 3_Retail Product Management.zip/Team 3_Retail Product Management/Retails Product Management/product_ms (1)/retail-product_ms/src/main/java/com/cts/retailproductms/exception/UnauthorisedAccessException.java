package com.cts.retailproductms.exception;

public class UnauthorisedAccessException extends Exception {

    public UnauthorisedAccessException(String msg) {
        super(msg);
    }
}

package com.cts.retailproductms.exception;

public class InternalServerErrorException extends Exception {

    public InternalServerErrorException(String msg) {
        // TODO Auto-generated constructor stub
        super(msg);
    }
}

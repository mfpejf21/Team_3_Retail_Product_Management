package com.cts.retailproductms.exception;

public class ProductNotFoundException extends Exception {

    public ProductNotFoundException(String msg) {
        super(msg);
    }
}

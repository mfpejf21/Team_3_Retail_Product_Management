package com.cts.retailproductproceedToBuyservice.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class TestProductNotFoundException {


    @InjectMocks
    ProductNotFoundException productNotFoundException;

    @Test
    void ProductNotFoundException() {

        productNotFoundException = new ProductNotFoundException("Token");
        assertEquals("Token", productNotFoundException.getMessage());
    }

    @Test
    void testProductNotFoundExceptionthrowcause() {
        productNotFoundException = new ProductNotFoundException(new Throwable("hii"));
        assertEquals("hii", productNotFoundException.getCause().getMessage());
    }

}

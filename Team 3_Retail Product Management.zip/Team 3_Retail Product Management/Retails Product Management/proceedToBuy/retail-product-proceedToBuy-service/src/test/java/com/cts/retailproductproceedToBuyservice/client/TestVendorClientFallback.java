package com.cts.retailproductproceedToBuyservice.client;

import com.cts.retailproductproceedToBuyservice.DTO.Vendor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class TestVendorClientFallback {

    @InjectMocks
    VendorClientFallback vendorClientFallback;

    @Test
    void getVendors() {
        List<Vendor> result = vendorClientFallback.getVendors("token", 2, 5);
        assertEquals(null, result);
    }

    @Test
    void getDeliveryCharge() {
        double result = vendorClientFallback.getDeliveryCharge("token", 1);
        assertEquals(0, result);
    }
}

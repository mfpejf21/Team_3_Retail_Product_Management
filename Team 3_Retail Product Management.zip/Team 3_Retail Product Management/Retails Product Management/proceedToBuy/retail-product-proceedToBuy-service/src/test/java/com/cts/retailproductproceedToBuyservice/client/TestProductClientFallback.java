package com.cts.retailproductproceedToBuyservice.client;

import com.cts.retailproductproceedToBuyservice.DTO.Product;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
class TestProductClientFallback {

    @InjectMocks
    ProductClientFallback productClientFallback;


    @Test
    void test() {
        String result = productClientFallback.test();

        assertEquals(null, result);
    }

    @Test
    void searchProductById() {
        ResponseEntity<Product> result = productClientFallback.searchProductById("token", 1);
        System.out.println(result);
        assertEquals(null, result);


    }
}

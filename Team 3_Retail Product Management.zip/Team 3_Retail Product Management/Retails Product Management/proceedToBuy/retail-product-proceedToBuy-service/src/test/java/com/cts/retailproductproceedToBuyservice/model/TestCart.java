package com.cts.retailproductproceedToBuyservice.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@RunWith(SpringRunner.class)
public class TestCart {

    Cart cart = new Cart();

    @BeforeEach
    public void setup() throws ParseException {
        Cart cart = new Cart();
        String sdate = "24/06/2021";
        Date date = new SimpleDateFormat("dd/MM/yyyy").parse(sdate);
        cart.setCartId(1);
        cart.setUserId(1);
        cart.setProductId(1);
        cart.setZipcode(12345);
        cart.setDeliveryDate(date);
        cart.setVendorId(1);
        cart.setQty(5);
    }


    @Test
    void testcartId() {
        Cart cart = new Cart();
        cart.setCartId(1);
        assertEquals(1, cart.getCartId());
    }

    @Test
    void testUserId() {
        Cart cart = new Cart();
        cart.setUserId(1);
        assertEquals(1, cart.getUserId());
    }

    @Test
    void testProductId() {
        Cart cart = new Cart();
        cart.setProductId(1);
        assertEquals(1, cart.getProductId());
    }

    @Test
    void testZipcode() {
        Cart cart = new Cart();
        cart.setZipcode(12345);
        assertEquals(12345, cart.getZipcode());
    }

    @Test
    void testDeliveryDate() throws ParseException {
        Cart cart = new Cart();
        String sdate = "24/06/2021";
        Date date = new SimpleDateFormat("dd/MM/yyyy").parse(sdate);
        cart.setDeliveryDate(date);
        assertEquals(date, cart.getDeliveryDate());
    }

    @Test
    void testVendorId() {
        Cart cart = new Cart();
        cart.setVendorId(1);
        assertEquals(1, cart.getVendorId());
    }

    @Test
    void testQty() {
        Cart cart = new Cart();
        cart.setQty(5);
        assertEquals(5, cart.getQty());
    }


    @Test
    public void noArgsConstructorTest() {
        Cart cart1 = new Cart();
        assertEquals(cart1, cart1);
    }

    @Test
    public void allArgsConstructorTest() throws ParseException {
        String sdate = "24/06/2021";
        Date date = new SimpleDateFormat("dd/MM/yyyy").parse(sdate);
        Cart cart = new Cart(1, 1, 1, 12345, date, 1, 5);
        assertEquals(1, cart.getCartId());
        assertEquals(1, cart.getUserId());
        assertEquals(1, cart.getProductId());
        assertEquals(12345, cart.getZipcode());
        assertEquals(date, cart.getDeliveryDate());
        assertEquals(1, cart.getVendorId());
        assertEquals(5, cart.getQty());
    }

}

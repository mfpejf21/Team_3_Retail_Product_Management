package com.cts.retailproductproceedToBuyservice.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@RunWith(SpringRunner.class)
public class TestVendorWishlist {
    VendorWishlist vendorWishlist1 = new VendorWishlist();

    @BeforeEach
    public void setup() throws ParseException {
        VendorWishlist vendorWishlist = new VendorWishlist();
        LocalDate date = LocalDate.of(2017, 1, 13);
        vendorWishlist.setWishlistId(1);
        vendorWishlist.setCustomerId(1);
        vendorWishlist.setProductId(1);
        vendorWishlist.setQuantity(5);
        vendorWishlist.setAddingDateToWishlist(date);
    }

    @Test
    void testWishlistId() {
        VendorWishlist vendorWishlist = new VendorWishlist();
        vendorWishlist.setWishlistId(1);
        assertEquals(1, vendorWishlist.getWishlistId());
    }

    @Test
    void testCustomerId() {
        VendorWishlist vendorWishlist = new VendorWishlist();
        vendorWishlist.setCustomerId(1);
        assertEquals(1, vendorWishlist.getCustomerId());
    }

    @Test
    void testProductId() {
        VendorWishlist vendorWishlist = new VendorWishlist();
        vendorWishlist.setProductId(1);
        assertEquals(1, vendorWishlist.getProductId());
    }

    @Test
    void testQuantity() {
        VendorWishlist vendorWishlist = new VendorWishlist();
        vendorWishlist.setQuantity(5);
        assertEquals(5, vendorWishlist.getQuantity());
    }

    @Test
    void testAddingDateToWishlist() {
        VendorWishlist vendorWishlist = new VendorWishlist();
        LocalDate date = LocalDate.of(2017, 1, 13);
        vendorWishlist.setAddingDateToWishlist(date);
        assertEquals(date, vendorWishlist.getAddingDateToWishlist());
    }

    @Test
    public void noArgsConstructorTest() {
        VendorWishlist vendorWishlist1 = new VendorWishlist();
        assertEquals(vendorWishlist1, vendorWishlist1);
    }

    @Test
    public void allArgsConstructorTest() throws ParseException {
        LocalDate date = LocalDate.of(2017, 1, 13);
        VendorWishlist vendorWishlist = new VendorWishlist(1, 1, 1, 5, date);

        assertEquals(1, vendorWishlist.getWishlistId());
        assertEquals(1, vendorWishlist.getCustomerId());
        assertEquals(1, vendorWishlist.getProductId());
        assertEquals(5, vendorWishlist.getQuantity());
        assertEquals(date, vendorWishlist.getAddingDateToWishlist());

    }
}

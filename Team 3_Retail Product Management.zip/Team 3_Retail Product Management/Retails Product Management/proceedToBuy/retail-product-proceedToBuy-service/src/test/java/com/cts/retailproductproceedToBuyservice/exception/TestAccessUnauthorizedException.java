package com.cts.retailproductproceedToBuyservice.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class TestAccessUnauthorizedException {

    @InjectMocks
    AccessUnauthorizedException accessUnauthorizedException;

    @Test
    void testAccessUnauthorizedException() {
        accessUnauthorizedException = new AccessUnauthorizedException("try again");
        assertEquals("try again", accessUnauthorizedException.getMessage());

    }

    @Test
    void testAccessUnauthorizedExceptionthrowcause() {
        accessUnauthorizedException = new AccessUnauthorizedException(new Throwable("hii"));
        assertEquals("hii", accessUnauthorizedException.getCause().getMessage());
    }

    @Test
    void testAccessUnauthorizedExceptionwithcauseandstring() {
        accessUnauthorizedException = new AccessUnauthorizedException(new Throwable("access"));
        assertEquals("access", accessUnauthorizedException.getCause().getMessage());
        accessUnauthorizedException = new AccessUnauthorizedException("hii");
        assertEquals("hii", accessUnauthorizedException.getMessage());
    }

}

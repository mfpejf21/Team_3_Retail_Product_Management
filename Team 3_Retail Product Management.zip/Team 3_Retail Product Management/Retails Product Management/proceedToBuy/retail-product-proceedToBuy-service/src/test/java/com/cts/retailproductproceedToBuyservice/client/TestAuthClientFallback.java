package com.cts.retailproductproceedToBuyservice.client;

import com.cts.retailproductproceedToBuyservice.exception.AccessUnauthorizedException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
class TestAuthClientFallback {

    @InjectMocks

    AuthClientFallback authClientFallback;

    @Test
    void getValidity() throws AccessUnauthorizedException {
        boolean result = authClientFallback.getValidity("test");

        assertFalse(result);

    }

    @Test
    void getId() {
        long result = authClientFallback.getId("token");
        assertEquals(0, result);

    }

    @Test
    void getZip() {
        int result = authClientFallback.getZip("token");
        System.out.println(result);
        assertEquals(0, result);

    }

    @Test
    void test() {
        String result = authClientFallback.test();

        assertEquals(null, result);
    }

    @Test
    void authclinetnotnull() {
        assertThat(authClientFallback).isNotNull();
    }

}

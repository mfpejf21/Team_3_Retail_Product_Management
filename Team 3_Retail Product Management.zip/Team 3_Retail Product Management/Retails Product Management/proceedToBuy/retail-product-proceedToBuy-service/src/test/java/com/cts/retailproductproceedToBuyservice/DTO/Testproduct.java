package com.cts.retailproductproceedToBuyservice.DTO;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class Testproduct {

    Product product = new Product();

    @Test
    @DisplayName("Checking if product class is loading or not.")
    void productIsLoadedOrNot() {
        Product product = new Product();
        assertThat(product).isNotNull();
    }


    @Test
    void id() {
        Product product = new Product();
        product.setId(1);
        assertEquals(1, product.getId());
    }

    @Test
    void name() {
        Product product = new Product();
        product.setName("kiran");
        assertEquals("kiran", product.getName());
    }

    @Test
    void description() {
        Product product = new Product();
        product.setDescription("Product is good");
        assertEquals("Product is good", product.getDescription());
    }

    @Test
    void image_name() {
        Product product = new Product();
        product.setImage_name("product");
        assertEquals("product", product.getImage_name());
    }

    @Test
    void rating() {
        Product product = new Product();
        product.setRating(9);
        assertEquals(9, product.getRating());
    }

    @Test
    void count() {
        Product product = new Product();
        product.setCount(10);
        assertEquals(10, product.getCount());
    }

    @Test
    public void AllArgConstTest() {
        Product product = new Product(1, "kiran", 50, "Product is good", "product", 9, 10);
        assertEquals(1, product.getId());
        assertEquals("kiran", product.getName());
        assertEquals("Product is good", product.getDescription());
        assertEquals("product", product.getImage_name());
        ;
        assertEquals(9, product.getRating());
        assertEquals(10, product.getCount());

    }

    @Test
    public void noArgsConstructorTest() {
        Product product1 = new Product();
        assertEquals(product1, product1);
    }
}




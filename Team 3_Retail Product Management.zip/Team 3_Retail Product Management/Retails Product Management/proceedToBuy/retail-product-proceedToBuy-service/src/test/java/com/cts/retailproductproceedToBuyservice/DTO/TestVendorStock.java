package com.cts.retailproductproceedToBuyservice.DTO;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@ExtendWith(MockitoExtension.class)
public class TestVendorStock {

    VendorStock vendorStock = new VendorStock();


    @Test
    @DisplayName("Checking if VendorStock class is loading or not.")
    void viewBillsDTODTOIsLoadedOrNot() {
        VendorStock vendorStock = new VendorStock();
        assertThat(vendorStock).isNotNull();
    }

    @Test
    void vendorStockId() {
        vendorStock.setVendorStockId(2);
        ;
        assertEquals(2, vendorStock.getVendorStockId());
    }

    @Test
    void productId() {
        vendorStock.setProductId(4);
        ;
        assertEquals(4, vendorStock.getProductId());
    }

    @Test
    void vendorId() {
        vendorStock.setVendorId(1);
        assertEquals(1, vendorStock.getVendorId());
    }

    @Test
    void stockInHand() {
        vendorStock.setStockInHand(45);
        assertEquals(45, vendorStock.getStockInHand());
    }

    @Test
    void expectedStockReplinshmentDate() {
        vendorStock.setExpectedStockReplinshmentDate("name");
        assertEquals("name", vendorStock.getExpectedStockReplinshmentDate());
    }

    @Test
    public void AllArgConstTest() {
        VendorStock vendorStock = new VendorStock(1, 1, 1, 40, "12-12-2020");
        assertEquals(1, vendorStock.getVendorStockId());
        assertEquals(1, vendorStock.getProductId());
        assertEquals(1, vendorStock.getVendorId());
        assertEquals(40, vendorStock.getStockInHand());
        assertEquals("12-12-2020", vendorStock.getExpectedStockReplinshmentDate());

    }

}



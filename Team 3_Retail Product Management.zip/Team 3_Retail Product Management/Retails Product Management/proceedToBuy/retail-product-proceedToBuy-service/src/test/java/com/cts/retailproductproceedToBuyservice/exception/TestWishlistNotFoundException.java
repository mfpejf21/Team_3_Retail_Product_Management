package com.cts.retailproductproceedToBuyservice.exception;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class TestWishlistNotFoundException {

    @InjectMocks
    WishlistNotFoundException wishlistNotFoundException;

    @Test
    public void testNoArgConstructorWishlistNotFoundException() {
        wishlistNotFoundException = new WishlistNotFoundException();
        assertEquals(null, wishlistNotFoundException.getMessage());
    }


    @Test
    void testWishlistNotFoundExceptionthrowcause() {
        wishlistNotFoundException = new WishlistNotFoundException(new Throwable("hii"));
        assertEquals("hii", wishlistNotFoundException.getCause().getMessage());
    }


}

package com.cts.retailproductproceedToBuyservice.client;

import com.cts.retailproductproceedToBuyservice.DTO.Product;
import org.springframework.http.ResponseEntity;

public class ProductClientFallback implements ProductClient {

    @Override
    public String test() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ResponseEntity<Product> searchProductById(String token, int productId) {
        // TODO Auto-generated method stub
        return null;
    }

}

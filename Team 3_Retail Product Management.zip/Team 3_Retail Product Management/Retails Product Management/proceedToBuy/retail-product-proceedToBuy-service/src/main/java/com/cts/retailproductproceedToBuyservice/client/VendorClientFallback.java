package com.cts.retailproductproceedToBuyservice.client;

import com.cts.retailproductproceedToBuyservice.DTO.Vendor;

import java.util.List;

public class VendorClientFallback implements VendorClient {

    @Override
    public List<Vendor> getVendors(String token, int productId, int quantity) {
        // TODO Auto-generated method stub
        return null;
    }


    @Override
    public double getDeliveryCharge(String token, int vendorId) {
        // TODO Auto-generated method stub
        return 0;
    }

}

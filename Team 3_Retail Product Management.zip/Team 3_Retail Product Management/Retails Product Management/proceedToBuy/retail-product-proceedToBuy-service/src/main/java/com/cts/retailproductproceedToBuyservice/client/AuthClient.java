package com.cts.retailproductproceedToBuyservice.client;

import com.cts.retailproductproceedToBuyservice.exception.AccessUnauthorizedException;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

//@Headers("Content-Type: application/json")
@FeignClient(name = "authclient", url = "${feign.url.auth-ms}", fallback = AuthClientFallback.class)
//@FeignClient(url="http://localhost:8081/api/")
public interface AuthClient {

    @GetMapping("/validate")
    public boolean getValidity(@RequestHeader("Authorization") String token) throws AccessUnauthorizedException;

    @GetMapping("/getId")
    public long getId(@RequestHeader("Authorization") String token);

    @GetMapping("/getZip")
    public int getZip(@RequestHeader("Authorization") String token);

    @GetMapping("/test")
    public String test();
}

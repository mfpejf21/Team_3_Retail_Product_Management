package com.cts.retailproductproceedToBuyservice.repository;

import com.cts.retailproductproceedToBuyservice.model.VendorWishlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WishlistRepository extends JpaRepository<VendorWishlist, Integer> {

    public List<VendorWishlist> findByCustomerId(long customerId);

    public VendorWishlist findByCustomerIdAndProductId(long customerId, int productId);

}

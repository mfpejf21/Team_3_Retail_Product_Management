package com.cts.retailproductproceedToBuyservice.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Vendor {
    public int vendorId;
    public String vendorName;
    public long deliveryCharge;
    public double rating;
}

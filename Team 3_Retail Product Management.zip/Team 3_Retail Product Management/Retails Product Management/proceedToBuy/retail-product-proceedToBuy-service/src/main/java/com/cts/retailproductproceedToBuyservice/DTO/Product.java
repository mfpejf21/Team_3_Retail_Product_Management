package com.cts.retailproductproceedToBuyservice.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class Product {

    private int id;
    private String name;
    private float price;
    private String description;
    private String image_name;
    private float rating;
    private int count;
}

